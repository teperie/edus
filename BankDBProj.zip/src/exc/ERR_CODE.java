package exc;

public enum ERR_CODE {
	ACCID, DOUBLEID, DEPOSIT, WITHDRAW, MENU
}
