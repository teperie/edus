document.write("Hello Javascript!");
